import java.util.Scanner;

public class AirplaneSeatsDemo {
    public static void main(String[] args) {
        AirplaneSeats airplane = new AirplaneSeats();


        System.out.println("You will be selecting seats for this airplane.");
        int[][] planeSize = new int[airplane.getAirplaneLength()][airplane.getAirplaneWidth()];
        airplane.initializeArray();
        airplane.seatNumbering(planeSize);

        System.out.println("You will input the seat selection using the row number and then the seat letter (ex - 3B)");
        while (!airplane.isFull()){
            Scanner scanner = new Scanner(System.in);
            System.out.println("Please enter the seat number or Q to quit.");
            System.out.println();
            String input = scanner.next();
            airplane.fillSeat(input);
            airplane.seatNumbering(planeSize);
        }

    }
}