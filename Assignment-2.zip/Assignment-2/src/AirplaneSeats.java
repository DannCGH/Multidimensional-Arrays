public class AirplaneSeats {
    private boolean full = false;
    private int airplaneLength = 7;
    private int airplaneWidth = 5;
    private int filledSeats = 0;

    public int getAirplaneLength() {
        return airplaneLength;
    }

    public int getAirplaneWidth() {
        return airplaneWidth;
    }

    public boolean isFull() {
        return full;
    }

    public String[][] seatNumber = new String[airplaneLength][airplaneWidth];

    public void initializeArray() {
        for (int row = 0; row < seatNumber.length; row++) {
            for (int col = 0; col < seatNumber[row].length; col++) {
                seatNumber[row][col] = "";
            }
        }
    }

    public void seatNumbering(int[][] arr) {
        for (int row = 0; row < arr.length; row++) {
            for (int col = 0; col < arr[row].length; col++) {
                if (col > 0){
                    if (!(seatNumber[row][col].equals("X"))) {
                        seatNumber[row][col] = (Integer.toString(row + 1) + (char) (col + 64));
                        System.out.print(((char)(col + 64)) + " ");
                    } else {
                        System.out.print("X ");
                    }
                } else {
                    System.out.print((row + 1) + " ");
                }
            }
            System.out.println();
        }
        System.out.println();
    }

    public void fillSeat(String seat){

        if (seat.equals("Q")) {
            System.exit(0);
        } else {
            boolean invalid = true;
            outerLoop:
            for (int row = 0; row < seatNumber.length; row++) {
                for (int col = 0; col < seatNumber[row].length; col++) {
                    if (seatNumber[row][col].equals(seat)) {
                        seatNumber[row][col] = "X";
                        filledSeats++;
                        if (filledSeats == (seatNumber.length * (seatNumber[row].length - 1))) {
                            System.exit(0);
                        }
                        invalid = false;
                        break outerLoop;
                    }
                }
            }
            if (invalid) {
                System.out.println("This seat is invalid. Please try again.");
            }
        }
    }

}
